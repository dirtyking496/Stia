import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
const cors={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS' }
const MODEL='fal-ai/wan/v2.2-5b/text-to-video'
serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors})
 try{
  if(req.method!=='POST')throw new Error('Méthode non autorisée')
  const key=Deno.env.get('FAL_KEY');if(!key)throw new Error('Secret FAL_KEY manquant dans Supabase.')
  const body=await req.json();const prompt=String(body.prompt||'').trim();if(prompt.length<8||prompt.length>2000)throw new Error('Le prompt doit contenir entre 8 et 2000 caractères.')
  const ratio=['9:16','16:9','1:1'].includes(body.aspect_ratio)?body.aspect_ratio:'9:16'
  const submit=await fetch(`https://queue.fal.run/${MODEL}`,{method:'POST',headers:{'Authorization':`Key ${key}`,'Content-Type':'application/json'},body:JSON.stringify({prompt,aspect_ratio:ratio,resolution:'720p',enable_safety_checker:true,enable_prompt_expansion:true})})
  const queued=await submit.json();if(!submit.ok)throw new Error(queued.detail||queued.error||'Impossible de démarrer la génération.')
  let state=queued;const statusUrl=queued.status_url;const resultUrl=queued.response_url
  for(let i=0;i<150;i++){
   await new Promise(r=>setTimeout(r,2000))
   const check=await fetch(statusUrl,{headers:{'Authorization':`Key ${key}`}});state=await check.json();if(!check.ok)throw new Error(state.detail||'Erreur de suivi du rendu.')
   if(state.status==='COMPLETED')break
  }
  if(state.status!=='COMPLETED')throw new Error('La génération prend trop de temps. Réessaie dans quelques minutes.')
  if(state.error)throw new Error(state.error)
  const resultRes=await fetch(resultUrl,{headers:{'Authorization':`Key ${key}`}});const result=await resultRes.json();if(!resultRes.ok)throw new Error(result.detail||'Résultat vidéo indisponible.')
  const videoUrl=result.video?.url||result.video_url||result.output?.video?.url
  if(!videoUrl)throw new Error('Le fournisseur n’a pas retourné de lien vidéo exploitable.')
  return new Response(JSON.stringify({videoUrl,requestId:queued.request_id,model:MODEL}),{headers:{...cors,'Content-Type':'application/json'}})
 }catch(e){return new Response(JSON.stringify({error:e.message||'Erreur inconnue'}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
})
